{{- define "premise.config.defaults" -}}
enabled: true
storageType: MYSQL
appManagerEndpoint: "{{ .Values.appManagerEndpoint }}"
regionId: "{{ .Values.regionId }}"
accountOwner: "{{ .Values.accountOwner }}"
signSecret: "{{ .Values.signSecret }}"
httpConnectionPoolMaxIdleConnections: {{ .Values.httpConnectionPoolMaxIdleConnections }}
scheduler:
  sch.group.name: {{ .Values.service.scheduler.schGroupName }}
  sch.capacity: {{ or .Values.service.scheduler.schCapacity 5000 }}
  sch.interval.ms: {{ .Values.service.scheduler.schIntervalMs }}
  sch.history.clear.ttl.sec: {{ or .Values.service.scheduler.schHistoryClearTtlSec 259200 }}
{{- end }}
