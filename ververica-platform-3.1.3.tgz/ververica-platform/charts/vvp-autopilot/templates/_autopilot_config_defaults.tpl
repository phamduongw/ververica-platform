{{- define "autopilot.config.defaults" -}}
enabled: true
agentFactory: RTC
storageType: MYSQL
serviceMode: "{{ .Values.serviceMode }}"
gatewayEndpoint: "{{ .Values.gatewayEndpoint }}"
regionId: "{{ .Values.regionId }}"
groupId: "{{ .Values.groupId }}"
accountOwner: "{{ .Values.accountOwner }}"
signSecret: "{{ .Values.signSecret }}"
appmanagerMode: REAL
httpConnectionPoolMaxIdleConnections: {{ .Values.httpConnectionPoolMaxIdleConnections }}
worker:
  endpoint: "{{ template "autopilot.workerName" . }}:80"
  autopilotAgentThreadPoolSize: {{ .Values.autopilotAgentThreadPoolSize }}
  agentTickInterval: {{ .Values.agentTickInterval }}
  autopilotDiagnoseHistorySize: 8
  collectMetricsWithBatch: {{ .Values.collectMetricsWithBatch }}
heartbeat:
  maxFailure: 60
  interval: 5000
metricTags:
  clusterName: "{{ .Values.metricClusterName }}"
  componentName: "{{ .Values.metricComponentName }}"

{{- end }}