{{/*
Expand the name of the chart.
*/}}
{{- define "k8s-operator.name" -}}
{{- default .Chart.Name .Values.serviceAccount.name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "k8s-operator.fullname" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.serviceAccount.name }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "k8s-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "k8s-operator.labels" -}}
helm.sh/chart: {{ include "k8s-operator.chart" . }}
{{ include "k8s-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "k8s-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "k8s-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
RBAC rules for VvpDeployment CRs
*/}}
{{- define "k8s-operator.rbacRules" -}}
- apiGroups: ["v3.ververica.platform"]
  resources: ["vvp3deployments"]
  verbs: ["get", "list", "watch", "patch", "update"]
- apiGroups: ["v3.ververica.platform"]
  resources: ["vvp3deployments/status"]
  verbs: ["get", "patch", "update"]
- apiGroups: ["v3.ververica.platform"]
  resources: ["vvp3deployments/finalizers"]
  verbs: ["update"]
# Required for webhook API key validation — reads apikeySecretName-referenced Secrets
- apiGroups: [""]
  resources: ["secrets"]
  verbs: ["get"]
# Events: required for mirroring VVP deployment events to k8s core/v1 Events (VVP-8719).
# `get` (and `list`) are needed because KubernetesEventServiceImpl does an idempotent
# GET-before-CREATE on the event name — without them, every reconcile hits a 403 forbidden
# and the event mirroring silently drops. Observed during local E2E (EventMirroringE2eTest).
- apiGroups: [""]
  resources: ["events"]
  verbs: ["get", "list", "create", "patch", "update"]
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "k8s-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "k8s-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
