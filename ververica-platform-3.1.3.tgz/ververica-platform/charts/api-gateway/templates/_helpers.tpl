{{/* Generate actuator basic auth header */}}
{{- define "healthEndpointAuthHeader" }}
{{- with .Values.actuator.auth }}
{{- printf "Basic %s" (printf "%s:%s" .user .password | b64enc) }}
{{- end }}
{{- end }}
