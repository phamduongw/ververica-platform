{{/* app name */}}
{{- define "appname" -}}
{{- $appname := "vvp" }}
{{- printf "%s" $appname -}}
{{- end }}

{{/* component */}}
{{- define "component" -}}
{{- $component := "advisor" }}
{{- printf "%s" $component -}}
{{- end }}

{{/* gateway name */}}
{{- define "advisor.name" -}}
{{- $name := "advisor" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/* service account name */}}
{{- define "advisor.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "advisor.name" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
