{{/*
common.flinkDefaultsBlob — emit a *Defaults blob for the ConfigMap, OpenShift-aware.

Lives in the library chart because two charts render these blobs: vvp-appmanager for deployments
and session clusters, and vvp-appagent for the vvp-sql and vvp-jar services. Both create Flink
JobManager and TaskManager pods, so both need the same OpenShift treatment; when only the
appmanager copy had it, Flink pods created by the SQL or JAR path had no credential path on
OpenShift at all (VCP-13131).

These blobs are literal YAML strings applied by AppManager to the Flink pods it creates at
runtime, so no Helm conditional inside them can react to the target platform. The chart's
own defaults carry `kubernetes.pods.securityContext.fsGroup: 10999` for FEED-953, and
OpenShift's default restricted-v2 SCC uses `fsGroup: MustRunAs` validated against a GID
range it allocates per namespace — so a fixed GID is rejected at admission in every
namespace and no Flink deployment or session cluster can start (VCP-13079).

Off OpenShift the string is emitted verbatim, byte for byte, so rendered output is
unchanged. On OpenShift the blob is parsed and the fixed group settings are removed, letting
the SCC assign the GID exactly as `common.podSecurityContext` already does for the platform
tier. FEED-953's intent survives: OpenShift still applies an fsGroup, it just picks the value.

`fsGroupChangePolicy` goes with it — it only qualifies how an fsGroup is applied, so leaving
it behind alone would be meaningless. An empty `securityContext` is dropped rather than
emitted as null.

Only the group settings are touched. A `runAsUser` or `runAsGroup` an operator puts in these
values is left alone rather than silently rewritten; `check-flink-defaults.sh` fails the build
on it instead, so the operator is told rather than second-guessed.

Expect a large textual diff on the OpenShift render: parsing round-trips the blob, so comments
are dropped, keys sort alphabetically, and scalar quoting normalises. Only the group settings
change semantically. Off OpenShift nothing is parsed, which is why that path stays byte-identical.

Parsing rather than `tpl`-ing the string is deliberate: these values are user-overridable
(overriding replaces the whole block), and running `tpl` over user-supplied content would
both break blobs containing brace syntax and turn a values file into a template-injection
surface. Parsing also means a user's own override is corrected on OpenShift too, not just
the chart default.

`pullSecret` (optional) carries the registry pull secret onto the Flink JM/TM pod spec, and is
set ONLY on OpenShift, inside the same branch as the group settings above (VCP-13131). On
OpenShift the ServiceAccount cannot carry it: the SA controller owns `.imagePullSecrets` and
Helm's server-side apply cannot take a field another manager holds, so
`vvp-appagent/templates/vvr-job-rabc.yaml` omits it there (VCP-13123 D18) and every Flink image
pull failed with `Init:ImagePullBackOff`. `kubernetes.pods.imagePullSecrets` reaches those pods
instead — AppManager applies it in the same pass as `volumeMounts` and `envVars`
(`PodTemplateConfigureUserPodOptions.apply`), both of which are observed arriving in
natively-created JM/TM pods.

Pass it only for the SYSTEM blobs. `globalDeploymentDefaults` and `globalSessionClusterDefaults`
are the operator's surface; the platform does not write into them.

The value must be a list of MAPPINGS. AppManager deserialises this into
`List<KubernetesOptions.Pods.LocalObjectReference>`, whose only `@JsonCreator` takes properties
(`name`, `dockerConfigJson`) — a bare string fails to deserialise, and because
`UserGlobalDeploymentDefaultsParser` wraps any failure in `GlobalDeploymentDefaultsFailure`, that
means AppManager does not start at all. `check-flink-defaults.sh` enforces the shape.

Usage: {{ include "common.flinkDefaultsBlob" (dict "blob" .Values.systemDeploymentDefaults "context" . "pullSecret" "ververica-registry") }}
*/}}
{{- define "common.flinkDefaultsBlob" -}}
{{- $blob := .blob -}}
{{- $pullSecret := .pullSecret | default "" -}}
{{- if ne (include "common.isOpenShift" .context) "true" -}}
{{- $blob -}}
{{- else -}}
{{- $parsed := fromYaml $blob -}}
{{- $spec := $parsed.spec | default dict -}}
{{- /* Deployment defaults nest under spec.template.spec; session-cluster defaults under spec. */ -}}
{{- $holder := $spec -}}
{{- if $spec.template -}}
{{- $holder = ($spec.template).spec | default dict -}}
{{- end -}}
{{- $pods := ($holder.kubernetes | default dict).pods | default dict -}}
{{- if $pullSecret -}}
{{- $k8s := $holder.kubernetes | default dict -}}
{{- /* Two hazards here, and both are silent.

       `set` only reaches the rendered output when it writes to a map actually attached to
       `$parsed`. Every `| default dict` in this helper hands back a FRESH map when its input is
       absent, null, OR an empty map — sprig treats `{}` as falsey — so writing through `$pods`
       above would be discarded for a blob carrying `pods: {}`, leaving OpenShift broken with no
       error at all. So bind to the attached map explicitly below, and reject the cases where
       there is nothing to bind to.

       `kindIs "map"` is the exact test: false when `pods` is missing or explicitly null (nothing
       attached, must refuse), true for `{}` and for a populated block (attached, safe to write).
       Refusing rather than silently proceeding matches the runAsUser principle above. */ -}}
{{- if not (kindIs "map" $k8s.pods) -}}
{{- fail "vvp-appmanager: systemDeploymentDefaults and systemSessionClusterDefaults must keep their kubernetes.pods block. On OpenShift that block carries the registry pull secret for Flink JobManager and TaskManager pods; without it no Flink image can be pulled. Add your settings alongside the existing kubernetes.pods keys rather than replacing them." -}}
{{- end -}}
{{- $pods = $k8s.pods -}}
{{- /* Append, never replace. An operator who lists their own registry secrets here keeps them —
       same principle as leaving their runAsUser alone. Kubelet tries each entry, so carrying both
       is correct, and re-running is idempotent because a matching name is not added twice. */ -}}
{{- $existing := $pods.imagePullSecrets | default list -}}
{{- $names := list -}}
{{- range $existing -}}
{{- if kindIs "map" . -}}{{- $names = append $names .name -}}{{- end -}}
{{- end -}}
{{- if not (has $pullSecret $names) -}}
{{- $_ := set $pods "imagePullSecrets" (append $existing (dict "name" $pullSecret)) -}}
{{- end -}}
{{- end -}}
{{- $sc := $pods.securityContext | default dict -}}
{{- if $sc -}}
{{- $_ := unset $sc "fsGroup" -}}
{{- $_ := unset $sc "fsGroupChangePolicy" -}}
{{- if not $sc -}}
{{- $_ := unset $pods "securityContext" -}}
{{- end -}}
{{- end -}}
{{- toYaml $parsed -}}
{{- end -}}
{{- end }}
