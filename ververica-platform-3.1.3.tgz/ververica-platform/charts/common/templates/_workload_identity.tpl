{{/*
Workload Identity helpers — shared across all VVP sub-charts.

Driven by global.workloadIdentity.azure.{clientId, tenantId}. The shape mirrors the
public VVP2 Helm key (`vvp.workloadIdentity.azure.*` in VVP2 docs); on VVP3 it lives
under `global:` because VVP3 is an umbrella + multi-subchart layout.

A non-empty `clientId` enables Workload Identity wiring. `tenantId` is optional and
only needed for cross-tenant scenarios; when set it adds the tenant-id SA annotation.
*/}}

{{/*
Render ServiceAccount annotations for Azure Workload Identity.

Usage (call with the root context; inside a {{ range }}, pass `$`):

  metadata:
    annotations:
      {{- include "common.workloadIdentity.saAnnotations" . | nindent 6 }}

Renders nothing when Workload Identity is disabled, so it is safe to drop into any
ServiceAccount metadata block unconditionally.
*/}}
{{- define "common.workloadIdentity.saAnnotations" -}}
{{- $clientId := ((((.Values).global).workloadIdentity).azure).clientId -}}
{{- if $clientId -}}
azure.workload.identity/client-id: {{ $clientId | quote }}
{{- $tenantId := ((((.Values).global).workloadIdentity).azure).tenantId -}}
{{- if $tenantId }}
azure.workload.identity/tenant-id: {{ $tenantId | quote }}
{{- end }}
{{- end -}}
{{- end -}}

{{/*
Render the Workload Identity pod label for VVP service pods directly managed by this
chart. Flink JM/TM pods get the same label via Flink's `kubernetes.{jm,tm}.labels`
config — that is injected by AppManager in Java code, not here.

Usage:

  spec:
    template:
      metadata:
        labels:
          {{- include "common.workloadIdentity.podLabels" . | nindent 10 }}
*/}}
{{- define "common.workloadIdentity.podLabels" -}}
{{- $clientId := ((((.Values).global).workloadIdentity).azure).clientId -}}
{{- if $clientId -}}
azure.workload.identity/use: "true"
{{- end -}}
{{- end -}}
