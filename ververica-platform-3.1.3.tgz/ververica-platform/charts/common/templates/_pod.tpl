{{/*
common.podAnnotations — merge pod template annotations from three sources.

Merge order (last-write-wins, permissive override policy):
  1. Chart hardcoded annotations  — passed via the 'hardcoded' dict in the include call.
  2. Global user annotations      — .Values.global.podAnnotations (set on the umbrella chart).
  3. Chart-local user annotations — .Values.podAnnotations (set on the sub-chart directly).

Permissive override policy: a key supplied by the user in podAnnotations that collides with
a hardcoded annotation overrides the hardcoded value. This is intentional — operators that
know what they are doing (e.g., disabling admission-webhook/eniSecurityReinforce for a
specific pod) can do so without forking the chart.

Empty-map normalisation: both `podAnnotations: {}` and `podAnnotations: null` are treated as
"no user annotations". The helper emits nothing when the merged set is empty, so no spurious
`annotations: {}` block is rendered.

Call signature:
  {{- include "common.podAnnotations" (dict "context" . "hardcoded" (dict "key1" "val1" "key2" "val2")) | nindent N }}

If a chart has no hardcoded annotations pass an empty dict:
  {{- include "common.podAnnotations" (dict "context" . "hardcoded" (dict)) | nindent N }}

Reference render assertions (for manual verification — no helm-unittest yet, see FU-2):
  Scenario A — empty values:
    input:  podAnnotations: {}  global.podAnnotations: {}  hardcoded: {k: v}
    expect: k: v
  Scenario B — local override:
    input:  podAnnotations: {foo: bar}  hardcoded: {k: v}
    expect: k: v + foo: bar
  Scenario C — permissive collision (user wins):
    input:  podAnnotations: {k: user}  hardcoded: {k: hardcoded}
    expect: k: user
  Scenario D — null local:
    input:  podAnnotations: null  hardcoded: {}
    expect: (nothing rendered — no annotations block)
*/}}
{{- define "common.podAnnotations" -}}
{{- $hardcoded := .hardcoded | default (dict) -}}
{{- $global    := ((.context.Values.global).podAnnotations) | default (dict) -}}
{{- $local     := (.context.Values.podAnnotations) | default (dict) -}}
{{/*
  Build the merged map with last-write-wins order: hardcoded → global → local.
  We use mustMergeOverwrite so that later sources (global, local) win over earlier ones.
  mustMergeOverwrite(dst, src): dst is mutated so that src keys override dst keys.
  Chain: start with hardcoded, overwrite with global, overwrite with local.
*/}}
{{- $merged := mustMergeOverwrite (deepCopy $hardcoded) $global -}}
{{- $merged  = mustMergeOverwrite $merged $local -}}
{{- if $merged -}}
{{- toYaml $merged -}}
{{- end -}}
{{- end -}}

{{/*
common.logLevelEnv — emit two container env entries for log-level configuration.

Covers two populations of services:
  - Custom-logback services: consume the env var `logLevel` via ${logLevel:-INFO} in
    their logback.xml (vvp-jar-service, vvp-sql-service, vvp-appmanager-agent).
  - Spring Boot default-logging services: consume LOGGING_LEVEL_ROOT natively when no
    custom logback.xml is present (all other VVP3 services).

Both env vars receive the same resolved value. Resolution chain:
  1. .Values.logLevel        (chart-local, non-empty string wins)
  2. .Values.global.logLevel (umbrella global, non-empty string wins)
  3. "INFO"                  (built-in default)

The env vars are always emitted — `--set logLevel=""` does not suppress emission; the helper
falls back to "INFO" via the resolution chain above. Containers always carry an explicit
`logLevel` and `LOGGING_LEVEL_ROOT` env value so that downstream behaviour (custom logback
substitution and Spring Boot auto-config) is deterministic regardless of whether the operator
set the value or not.

Known gap: vvp-autopilot-worker ships a custom logback.xml that does not reference
${logLevel}, and Spring Boot's auto-config is disabled when a custom logback is present, so
LOGGING_LEVEL_ROOT has no effect there. Tracked as FU-3.

Call signature (append after the chart's hardcoded env block, before any {{- if .Values.env }}):
  {{- include "common.logLevelEnv" . | nindent M }}
*/}}
{{- define "common.logLevelEnv" -}}
{{- $local  := .Values.logLevel | default "" -}}
{{- $global := ((.Values.global).logLevel) | default "" -}}
{{- $level  := $local | default $global | default "INFO" -}}
- name: logLevel
  value: {{ $level | quote }}
- name: LOGGING_LEVEL_ROOT
  value: {{ $level | quote }}
{{- end -}}
