{{/*
common.probes — renders livenessProbe, readinessProbe and startupProbe from a values block.

Why this exists: every VVP3 workload hardcoded its probes with no startupProbe, so the liveness
probe policed boot time — which is not what it is for. vvp-appmanager granted boot
60s + 10 x 10s = 160s; QA's in-place 3.1.1 -> 3.1.3-rc2 upgrade on OpenShift Local exceeded it, the
kubelet restarted the container, and the pod never reached Ready until the probe was hand-patched on
the live StatefulSet (VCP-14190). A startupProbe gates liveness and readiness until the app is up, so
boot time and steady-state supervision stop competing for the same numbers.

Why a pre-built "handler" dict instead of switching on probe type: the endpoint varies across
workloads in every possible way — httpGet vs tcpSocket, /actuator vs /actuator/health, literal ports
vs .Values.service.* expressions, and api-gateway's Authorization header. Passing the handler in
makes all of that data rather than branches, so this helper carries exactly one conditional. It also
keeps the endpoint at the call site, next to the containerPort it has to agree with — a second
source of truth for a probe port is how you get a probe aimed at a port nothing listens on.

Why no "context" dict: unlike common.podAnnotations and common.pg-database-init-container, nothing
in here reads .Values or .Release, so the caller passes only what the helper actually needs.

The bare template name "probes" is forbidden tree-wide. Helm's template namespace is global across
the whole chart tree, so two definitions of one name silently override by load order — one service
rendering another service's probes, with no error and no warning. Always namespace: common.* or
<chart>.*.

Startup and liveness never emit successThreshold: Kubernetes requires it to be 1 for both, and the
default is 1. Readiness emits it only where the workload declares one today.

Every timing is validated before anything is emitted, because the silent failure here is worse than
the bug this helper fixes. Reading a missing value does NOT error in Go templates -- it renders
empty -- so a nil `probes` block would emit `failureThreshold:` with no value, the API server would
substitute its own defaults (failureThreshold 3, timeoutSeconds 1), and a startupProbe meant to
grant 630s would silently grant ~30s. Verified by rendering it. Hence `fail` on a missing field
rather than trusting the render to blow up on its own.

Usage:
  {{- include "common.probes" (dict
        "probes"  .Values.probes
        "handler" (dict "httpGet" (dict "path"   "/actuator/health"
                                        "port"   .Values.service.managePort
                                        "scheme" "HTTP"))) | nindent 10 }}
*/}}
{{- define "common.probes" -}}
{{- $p := .probes | required "common.probes: .probes is required (pass .Values.probes)" -}}
{{- $handler := .handler | required "common.probes: .handler is required (pass a dict such as (dict \"httpGet\" (dict ...)))" -}}
{{- /*
     Validate before emitting. successThreshold is deliberately absent from the field lists:
     it is optional everywhere and must not be set on liveness or startup.
*/ -}}
{{- range $probe := list "liveness" "readiness" "startup" -}}
{{-   $cfg := index $p $probe | required (printf "common.probes: probes.%s is required" $probe) -}}
{{-   $fields := list "failureThreshold" "periodSeconds" "timeoutSeconds" -}}
{{-   if ne $probe "liveness" -}}
{{-     $fields = append $fields "initialDelaySeconds" -}}
{{-   end -}}
{{-   range $f := $fields -}}
{{-     if kindIs "invalid" (index $cfg $f) -}}
{{-       fail (printf "common.probes: probes.%s.%s is required and must be a number" $probe $f) -}}
{{-     end -}}
{{-   end -}}
{{- end -}}
livenessProbe:
{{ toYaml $handler | indent 2 }}
  failureThreshold: {{ $p.liveness.failureThreshold }}
  periodSeconds: {{ $p.liveness.periodSeconds }}
  timeoutSeconds: {{ $p.liveness.timeoutSeconds }}
  {{- with $p.liveness.successThreshold }}
  successThreshold: {{ . }}
  {{- end }}
readinessProbe:
{{ toYaml $handler | indent 2 }}
  failureThreshold: {{ $p.readiness.failureThreshold }}
  initialDelaySeconds: {{ $p.readiness.initialDelaySeconds }}
  periodSeconds: {{ $p.readiness.periodSeconds }}
  timeoutSeconds: {{ $p.readiness.timeoutSeconds }}
  {{- with $p.readiness.successThreshold }}
  successThreshold: {{ . }}
  {{- end }}
startupProbe:
{{ toYaml $handler | indent 2 }}
  failureThreshold: {{ $p.startup.failureThreshold }}
  initialDelaySeconds: {{ $p.startup.initialDelaySeconds }}
  periodSeconds: {{ $p.startup.periodSeconds }}
  timeoutSeconds: {{ $p.startup.timeoutSeconds }}
{{- end -}}
