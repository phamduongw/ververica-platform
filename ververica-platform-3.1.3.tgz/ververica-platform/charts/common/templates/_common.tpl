{{/*
Reads the secret 'ververica-platform-vvp-mysql', created by vvp-mysql, decodes and returns the value of 'mysql-root-password'.
`lookup` function does not work with helm diff, so there must be a conditional before decoding the key.
The function works with most recent versions of `help` with `--dry-run=server`.
*/}}

{{- define "common.mysql.password" -}}
{{- if .Values.global.database.passwordSecret }}
  {{- fail "common.mysql.password: caller must guard on .Values.global.database.passwordSecret and use secretKeyRef instead of calling this helper" -}}
{{- else if .Values.global.database.password }}
  {{- .Values.global.database.password -}}
{{- else }}
  {{- print "Err! Cannot Read Password from values.yaml" -}}
{{- end -}}
{{- end -}}

{{/*
Format image string from registry, repository, and tag
{{ include "common.image.format" .Values.image }}
*/}}
{{- define "common.image.format" -}}
{{ printf "%s/%s:%s" .registry .repository .tag }}
{{- end -}}

{{/*
Return the proper image name
{{ include "common.image.name" ( dict "imageRoot" .Values.path.to.the.image "globalImage" (.Values.global).image ) }}
*/}}
{{- define "common.image.name" -}}
{{- $registry := default .imageRoot.registry ((.globalImage).registry) -}}
{{- $repository := .imageRoot.repository -}}
{{- $tag := .imageRoot.tag -}}
{{- include "common.image.format" (dict "registry" $registry "repository" $repository "tag" $tag) -}}
{{- end -}}

{{/*
common.database.provider — returns the normalised dialect identifier for the given
database block. Defaults to "mariadb" when `.provider` is unset, so existing installs
(which had no `provider` field) keep their MariaDB behaviour. Mixed-case input
(e.g. "PostgreSQL") is lowercased so case differences do not silently fall through to
the MariaDB branch in the comparison helpers below.

Accepted values: "mysql", "mariadb", "postgresql".

VVP3 ships TWO JDBC drivers, each handling more than one server backend:
  - org.mariadb.jdbc.Driver  → MariaDB ✓ + MySQL ✓ (provider: "mariadb" or "mysql";
    the MariaDB driver speaks the MySQL wire protocol so a single driver covers both)
  - org.postgresql.Driver    → PostgreSQL ✓ (provider: "postgresql")

So at the application layer there are only two driver/URL paths to test, while the
chart-level `provider` field exposes the three server backends so install scripts +
Helm overlays can deploy + connect to each independently.

Usage:
  {{ include "common.database.provider" $db }}
*/}}
{{- define "common.database.provider" -}}
{{- lower (default "mariadb" .provider) -}}
{{- end -}}

{{/*
common.database.driver — returns the JDBC driver class name for the given database block.
Derived from `.provider`:
  - postgresql       → org.postgresql.Driver
  - {mariadb, mysql} → org.mariadb.jdbc.Driver  (also the fallback for unknown values)

Usage from a service chart configmap:
  driver-class-name: {{ include "common.database.driver" $db }}
*/}}
{{- define "common.database.driver" -}}
{{- $provider := include "common.database.provider" . -}}
{{- if eq $provider "postgresql" -}}
org.postgresql.Driver
{{- else -}}
org.mariadb.jdbc.Driver
{{- end -}}
{{- end -}}

{{/*
common.database.scheme — returns the JDBC URL scheme for the given database block
(the part between `jdbc:` and `://`). Derived from `.provider`:
  - postgresql       → postgresql
  - {mariadb, mysql} → mariadb  (also the safe fallback for unknown values)
Mirrors common.database.driver so the JDBC URL scheme is always consistent with the
selected driver — a typo like `provider: postgrres` falls back to mariadb on BOTH the
driver and scheme axes, avoiding a silent driver/scheme mismatch (which would surface
as `No suitable driver found` at runtime).

Usage from a service chart configmap:
  url: "jdbc:{{ include "common.database.scheme" $db }}://{{ $db.host }}:{{ $db.port }}/foo{{ include "common.database.urlSuffix" $db }}"
*/}}
{{- define "common.database.scheme" -}}
{{- $provider := include "common.database.provider" . -}}
{{- if eq $provider "postgresql" -}}
postgresql
{{- else -}}
mariadb
{{- end -}}
{{- end -}}

{{/*
common.database.urlSuffix — returns the trailing JDBC URL query string for the given
database block, derived from `.provider` + `.createIfMissing`.

  - {mysql, mariadb} + createIfMissing=true (default) → "?createDatabaseIfNotExist=true"
    (the MariaDB driver supports this flag against both MySQL and MariaDB servers)
  - {mysql, mariadb} + createIfMissing=false          → "" (DB must exist)
  - postgresql                                        → "" (auto-creation goes through the
    per-service pre-install Helm hook in
    charts/common/templates/_pg-database-init-container.tpl, not the JDBC driver)

User-supplied `.urlParams` overrides everything when set to a non-empty value —
useful for adding extras like `?ssl=true&sslmode=require` against a managed backend.
An explicit empty string (`urlParams: ""`) does NOT override; it falls through to
the createIfMissing-derived suffix below. Use a non-empty string (or unset the key)
to control behaviour.

Usage from a service chart configmap:
  url: "jdbc:{{ include "common.database.scheme" $db }}://{{ $db.host }}:{{ $db.port }}/foo{{ include "common.database.urlSuffix" $db }}"
*/}}
{{- define "common.database.urlSuffix" -}}
{{- /*
`dig` (not `default`) is used for createIfMissing so an explicit `false` is preserved.
Sprig's `default true false` returns true because it treats false as "empty"; `dig`
only falls back to the default when the key is actually missing.
*/}}
{{- $provider := include "common.database.provider" . -}}
{{- if .urlParams -}}
{{- .urlParams -}}
{{- else if and (or (eq $provider "mariadb") (eq $provider "mysql")) (dig "createIfMissing" true .) -}}
?createDatabaseIfNotExist=true
{{- end -}}
{{- end -}}

{{/*
common.upload.maxFileSize — returns the configured max artifact/JAR upload size
(a plain "<N>MB" string, e.g. "200MB") from global.upload.maxFileSize. Fails loudly
if the value isn't in that exact format — common.upload.maxRequestSize parses this
string with arithmetic that would otherwise silently miscompute (or hard-fail with
a cryptic type error) on a malformed value like "1GB", "200mb", or a bare number.

Usage from a service chart configmap:
  max-file-size: {{ include "common.upload.maxFileSize" . }}
*/}}
{{- define "common.upload.maxFileSize" -}}
{{- $val := toString .Values.global.upload.maxFileSize -}}
{{- if not (regexMatch "^[0-9]+MB$" $val) -}}
{{- fail (printf "global.upload.maxFileSize must be a plain \"<N>MB\" string (e.g. \"200MB\"); got %q" $val) -}}
{{- end -}}
{{- $val -}}
{{- end -}}

{{/*
common.upload.maxRequestSize — derives the Spring `max-request-size` limit from
global.upload.maxFileSize by adding a fixed 1MB buffer for multipart request overhead
beyond the file itself (e.g. "200MB" -> "201MB").

Usage from a service chart configmap:
  max-request-size: {{ include "common.upload.maxRequestSize" . }}
*/}}
{{- define "common.upload.maxRequestSize" -}}
{{- $maxFileSize := int (trimSuffix "MB" (include "common.upload.maxFileSize" .)) -}}
{{- printf "%dMB" (add $maxFileSize 1) -}}
{{- end -}}
