{{/*
common.isOpenShift — OpenShift detection for the securityContext helpers.
True when the cluster advertises security.openshift.io/v1 (live helm install)
or when global.security.openshift is set. The value override exists because
.Capabilities.APIVersions is only populated by a live cluster connection —
helm template / GitOps installs (ArgoCD, Flux) must set
global.security.openshift=true to get the OpenShift-safe manifests.
*/}}
{{- define "common.isOpenShift" -}}
{{- $global := (.Values.global).security | default (dict) -}}
{{- if or (has "security.openshift.io/v1" .Capabilities.APIVersions) ($global.openshift | default false) -}}true{{- end -}}
{{- end -}}

{{/*
common.podSecurityContext — pod-level securityContext, OpenShift-aware.
3-tier resolution: subchart .Values.securityContext -> .Values.global.security -> defaults.
On OpenShift (see common.isOpenShift) the fixed UID/GID/fsGroup are omitted so the
restricted SCC assigns an arbitrary UID (documented VVP 3.0.1 feature); runAsNonRoot + seccomp
are still emitted. Non-OpenShift keeps the fixed non-root UID/GID/fsGroup (default 10999).
*/}}
{{- define "common.podSecurityContext" -}}
{{- $local  := .Values.securityContext | default (dict) -}}
{{- $global := (.Values.global).security | default (dict) -}}
{{- $isOpenShift := eq (include "common.isOpenShift" .) "true" -}}
{{- $runAsNonRoot := $local.runAsNonRoot -}}
{{- if eq (kindOf $runAsNonRoot) "invalid" -}}{{- $runAsNonRoot = $global.runAsNonRoot -}}{{- end -}}
{{- if eq (kindOf $runAsNonRoot) "invalid" -}}{{- $runAsNonRoot = true -}}{{- end -}}
{{- $seccompType := (($local.seccompProfile).type) | default (($global.seccompProfile).type) | default "RuntimeDefault" -}}
runAsNonRoot: {{ $runAsNonRoot }}
seccompProfile:
  type: {{ $seccompType }}
{{- if not $isOpenShift }}
{{- $runAsUser := $local.runAsUser | default $global.runAsUser | default 10999 }}
{{- $runAsGroup := $local.runAsGroup | default $global.runAsGroup | default 10999 }}
{{- $fsGroup := $local.fsGroup | default $global.fsGroup | default 10999 }}
runAsUser: {{ $runAsUser }}
runAsGroup: {{ $runAsGroup }}
fsGroup: {{ $fsGroup }}
{{- end }}
{{- end -}}

{{/*
common.containerSecurityContext — container-level securityContext, OpenShift-aware.
On OpenShift the fixed runAsUser is omitted (SCC assigns it); allowPrivilegeEscalation:false,
capabilities.drop and runAsNonRoot are always emitted.
*/}}
{{- define "common.containerSecurityContext" -}}
{{- $local  := .Values.securityContext | default (dict) -}}
{{- $global := (.Values.global).security | default (dict) -}}
{{- $isOpenShift := eq (include "common.isOpenShift" .) "true" -}}
{{- $allowPE := $local.allowPrivilegeEscalation -}}
{{- if eq (kindOf $allowPE) "invalid" -}}{{- $allowPE = $global.allowPrivilegeEscalation -}}{{- end -}}
{{- if eq (kindOf $allowPE) "invalid" -}}{{- $allowPE = false -}}{{- end -}}
{{- $runAsNonRoot := $local.runAsNonRoot -}}
{{- if eq (kindOf $runAsNonRoot) "invalid" -}}{{- $runAsNonRoot = $global.runAsNonRoot -}}{{- end -}}
{{- if eq (kindOf $runAsNonRoot) "invalid" -}}{{- $runAsNonRoot = true -}}{{- end -}}
{{- $localCaps := $local.capabilities | default (dict) -}}
{{- $globalCaps := $global.capabilities | default (dict) -}}
{{- $caps := $localCaps.drop | default $globalCaps.drop | default (list "ALL") -}}
allowPrivilegeEscalation: {{ $allowPE }}
capabilities:
  drop:
{{- range $caps }}
    - {{ . }}
{{- end }}
runAsNonRoot: {{ $runAsNonRoot }}
{{- if not $isOpenShift }}
{{- $runAsUser := $local.runAsUser | default $global.runAsUser | default 10999 }}
runAsUser: {{ $runAsUser }}
{{- end }}
{{- end -}}

{{/*
Artifact-fetcher private-CA trust (FEED-978).
Driven by global.security.artifactFetcherCA:
  secretName         - secret holding a PREBUILT Java truststore (JKS/PKCS12) that
                       contains the private CA chain in addition to the public roots
  trustStoreKey      - key inside the secret (default "cacerts")
  trustStorePassword - truststore password (default "changeit")
The fetcher is an init container rendered by VVP itself, so a runtime keytool
import is not possible here; the truststore must be prebuilt. When unset, the
callers emit their original hardcoded config, byte-identical to before.
The volume is named "fetcher-ca" ON PURPOSE: the documented Flink kubernetes.pods
example uses "ca-truststore", and fetcher volumes are injected at pod level, so
reusing that name makes Kubernetes reject the pod (Duplicate value).
*/}}
{{- define "common.artifactFetcherCAEnv" -}}
{{- $ca := ((.root.Values.global).security).artifactFetcherCA | default (dict) -}}
{{- if .withComponent }}
- name: COMPONENT
  value: artifact-fetcher
{{- end }}
{{- if $ca.secretName }}
{{- $key := $ca.trustStoreKey | default "cacerts" }}
{{- $pw := $ca.trustStorePassword | default "changeit" }}
{{- if regexMatch "\\s" $pw }}
{{- fail "global.security.artifactFetcherCA.trustStorePassword must not contain whitespace: JAVA_TOOL_OPTIONS is space-tokenized by the JVM, so it would be parsed as a separate flag." }}
{{- end }}
{{- if regexMatch "\\s" $key }}
{{- fail "global.security.artifactFetcherCA.trustStoreKey must not contain whitespace." }}
{{- end }}
{{- $jto := printf "-Djavax.net.ssl.trustStore=/certs/%s -Djavax.net.ssl.trustStorePassword=%s" $key $pw }}
- name: JAVA_TOOL_OPTIONS
  value: {{ $jto | toJson }}
{{- end }}
{{- end -}}

{{- define "common.artifactFetcherCAVolumes" -}}
{{- $ca := ((.root.Values.global).security).artifactFetcherCA | default (dict) -}}
{{- with .cachePath }}
- name: cache-dir
{{- /* restricted-v2 and PodSecurity `restricted` both forbid hostPath outright, so the fetcher
       pod is refused before it starts. emptyDir keeps the mount contract and gives up only the
       node-level cache sharing — which is not load-bearing: the per-job fetchers configured in
       vvp-appagent/templates/agent-config.yaml run with no cache volume at all. */}}
{{- if eq (include "common.isOpenShift" $.root) "true" }}
  emptyDir: {}
{{- else }}
  hostPath:
    path: {{ . }}
    type: DirectoryOrCreate
{{- end }}
{{- end }}
{{- if $ca.secretName }}
- name: fetcher-ca
  secret:
    secretName: {{ $ca.secretName }}
{{- end }}
{{- end -}}

{{- define "common.artifactFetcherCAVolumeMounts" -}}
{{- $ca := ((.root.Values.global).security).artifactFetcherCA | default (dict) -}}
{{- if .withCache }}
- name: cache-dir
  mountPath: /vvp/filecache
{{- end }}
{{- if $ca.secretName }}
- name: fetcher-ca
  mountPath: /certs
  readOnly: true
{{- end }}
{{- end -}}
