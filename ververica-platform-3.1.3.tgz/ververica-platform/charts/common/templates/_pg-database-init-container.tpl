{{/*
common.pg-database-init-container — emits a Pod-level `initContainers` LIST ENTRY
that ensures one or more PostgreSQL databases exist before the main service
container starts.

Replaces the pre-install/pre-upgrade Helm Job that used to perform the same
function (see commit history for `_pg-database-job.tpl`). Init containers are
GitOps-friendlier (ArgoCD/Flux often exclude Helm hooks from sync), self-heal
naturally when PG is temporarily unavailable, and put failures in the same Pod
object as the service for easier debugging.

Activated only when:
  - global.database.provider == "postgresql"
  - global.database.createIfMissing != false (false = managed PG with no
    CREATEDB privilege; DBA pre-creates the databases out of band)

Skips silently (renders empty) when either condition is unmet. Because empty
output under a bare `initContainers:` key would render `initContainers: null`
(which fails Kubernetes schema validation), callers MUST guard the include with
`{{- with include ... }}` so the `initContainers:` key is only emitted when the
helper actually produces a container. See the usage example below.
The MariaDB / MySQL path needs no init container: the MariaDB JDBC driver's
`?createDatabaseIfNotExist=true` flag handles auto-creation at first connect.

Usage from a service chart's pod template (guarded — do NOT emit a bare
`initContainers:` key, or non-PG renders produce `initContainers: null`):

  spec:
    template:
      spec:
        {{- with include "common.pg-database-init-container" (dict
              "context" .
              "dbNames" (list "vvp-meta")) }}
        initContainers:
          {{- . | nindent 8 }}
        {{- end }}

  (A chart that already has other init containers includes the helper output as
  an additional list item under its existing `initContainers:` key instead —
  see charts/vvp-k8s-operator/templates/deployment.yaml.)

Pass a LIST of database names. Most services pass a single-element list naming
their own database. The one cross-service case is `vvp-appmanager`, which also
needs `vvp-k8soperator` when the operator is enabled — that's why this helper
accepts a list rather than a single name.

The container image (the Wiz-secured PostgreSQL image from the platform
registry by default — ships psql + pg_isready) is overridable via
`global.database.initContainer.{image, imagePullPolicy}` for air-gapped /
private-registry clusters that mirror images elsewhere. There is no
`imagePullSecrets` field here: the init container shares the pod's pull
secrets, so registry auth is configured once at the pod level (see each
service chart's `imagePullSecretName` / `global.imagePullSecretName`).

The container runs `pg_isready` in a wait loop (30 × 2s = up to 1 min) before
attempting `CREATE DATABASE`, so on a fresh install where bitnami/postgresql
is still cold-starting we don't CrashLoopBackOff — we just wait. Then for each
name in `dbNames`, the script does an idempotent
  SELECT 1 FROM pg_database WHERE datname='X' ; CREATE DATABASE "X" if missing
so re-runs on pod restart are safe and cheap. Authenticates as
`global.database.user`, which must have CREATEDB privilege (for in-cluster
bitnami PG that's the `postgres` superuser). Password comes from
`global.database.passwordSecret` (secretKeyRef) when set, else the plaintext
`global.database.password` — mirrors every other RDS_PASSWORD/DB_PASSWORD
consumer in the service charts.
*/}}
{{- define "common.pg-database-init-container" -}}
{{- $ctx := .context -}}
{{- $dbNames := .dbNames -}}
{{- $db := $ctx.Values.global.database -}}
{{- /* `dig` preserves an explicit `false` (Sprig's `default true false` coerces false→true). */ -}}
{{- if and (eq (include "common.database.provider" $db) "postgresql") (dig "createIfMissing" true $db) -}}
{{- /*
`dig` returns nil when `initContainer:` is declared with empty leaf keys (the
umbrella values.yaml documents image/imagePullPolicy with no default values),
so the leaf lookups below layer `default` (which DOES fall through on nil) on
top of a `dig` that gives us a non-nil dict to `.`-deref against.
*/ -}}
{{- $init := (dig "initContainer" (dict) $db) -}}
- name: pg-init
  # `global.database.initContainer.{image,imagePullPolicy}` (both optional) override
  # the defaults below. Default image is the Wiz-secured PostgreSQL image from the
  # platform registry (VCP-13045) — it ships pg_isready + psql, and psql v16 speaks
  # to any supported server version. Clusters mirroring images elsewhere should
  # override to their local path. Image pull secrets come from the pod's own
  # `spec.imagePullSecrets`, not a separate field here — init containers share
  # the pod's auth.
  image: {{ default "registry.ververica.cloud/platform-images/postgresql:16.14-0" $init.image | quote }}
  imagePullPolicy: {{ default "IfNotPresent" $init.imagePullPolicy }}
  # Regardless of the image's default user,
  # on non-OpenShift clusters we override with runAsUser: 1000 so the container
  # runs as a non-root UID (any non-zero UID works for psql/pg_isready client tools).
  # On OpenShift the restricted-v2 SCC assigns a UID from the namespace range
  # (e.g. 1000650000+), which is always non-root — so we omit runAsUser/runAsGroup
  # and let the SCC do it. This avoids needing anyuid SCC.
  # allowPrivilegeEscalation is always off and all capabilities are dropped —
  # psql/pg_isready need none. Both sit outside the non-OpenShift branch below
  # because PSS `restricted` and the OpenShift restricted-v2 SCC each require
  # them regardless of which UID the platform assigns.
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
        - ALL
  {{- if not (eq (include "common.isOpenShift" $ctx) "true") }}
    runAsNonRoot: true
    runAsUser: 1000
    runAsGroup: 1000
  {{- end }}
  env:
    {{- if $db.passwordSecret }}
    - name: PGPASSWORD
      valueFrom:
        secretKeyRef:
          name: {{ $db.passwordSecret | quote }}
          key: {{ default "password" $db.passwordSecretKey | quote }}
    {{- else }}
    - name: PGPASSWORD
      value: {{ $db.password | quote }}
    {{- end }}
  command: ["sh", "-c"]
  args:
    - |
      set -eu
      PG_HOST={{ $db.host | quote }}
      PG_PORT={{ $db.port | quote }}
      PG_USER={{ $db.user | quote }}
      # Wait for PostgreSQL to accept connections. On a fresh install the
      # bitnami/postgresql StatefulSet may still be cold-starting when our pod
      # is scheduled — 30 attempts × 2s = up to 1 minute. Tune if managed
      # backends with slower cold-start need more headroom.
      MAX_ATTEMPTS=30
      ATTEMPT=1
      echo "Waiting for PostgreSQL on $PG_HOST:$PG_PORT to accept connections..."
      until pg_isready -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d postgres >/dev/null 2>&1; do
        if [ "$ATTEMPT" -ge "$MAX_ATTEMPTS" ]; then
          echo "  PostgreSQL not reachable after $MAX_ATTEMPTS attempts — giving up." >&2
          exit 1
        fi
        echo "  Not ready yet (attempt $ATTEMPT/$MAX_ATTEMPTS), retrying in 2s..."
        ATTEMPT=$((ATTEMPT + 1))
        sleep 2
      done
      echo "  PostgreSQL is reachable."
      # Concurrency-safe CREATE DATABASE for each requested name.
      #
      # PostgreSQL has no `CREATE DATABASE IF NOT EXISTS`, and CREATE DATABASE
      # cannot run inside a transaction/DO block — so the usual
      # `DO $$ ... EXCEPTION WHEN duplicate_database $$` idempotency trick is not
      # available for databases. Two init containers can legitimately race for the
      # same database: appmanager ensures both `vvp-appmanager` and `vvp-k8soperator`
      # while the operator pod also ensures `vvp-k8soperator`, and both can observe
      # "missing" before either CREATE lands. The loser of that race would otherwise
      # get `ERROR: database "..." already exists` and fail the whole init container.
      #
      # Pattern: SELECT-first for the cheap/common path (already exists → no-op, clean
      # logs on pod restarts), then attempt CREATE and — if it fails — RE-CHECK
      # existence. If the database is now present, a concurrent creator won the race
      # and the desired state is achieved, so we treat it as success. Re-checking
      # pg_database (rather than grepping the error text) is version- and
      # locale-independent, and still fails hard on genuine errors (e.g. permission
      # denied, connection lost) because in those cases the database stays absent.
      for DB_NAME in {{ range $dbNames }}{{ . | quote }} {{ end }}; do
        echo "Ensuring PostgreSQL database '$DB_NAME' exists on $PG_HOST:$PG_PORT..."
        EXISTS=$(psql -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")
        if [ "$EXISTS" = "1" ]; then
          echo "  Database '$DB_NAME' already exists — nothing to do."
        else
          echo "  Database '$DB_NAME' missing — creating..."
          if CREATE_ERR=$(psql -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d postgres -c "CREATE DATABASE \"$DB_NAME\"" 2>&1); then
            echo "  Database '$DB_NAME' created."
          else
            RECHECK=$(psql -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")
            if [ "$RECHECK" = "1" ]; then
              echo "  Database '$DB_NAME' was created concurrently by another init container — ok."
            else
              echo "  Failed to create database '$DB_NAME':" >&2
              echo "$CREATE_ERR" >&2
              exit 1
            fi
          fi
        fi
      done
{{- end -}}
{{- end -}}
