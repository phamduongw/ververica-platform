{{- define "appmanager.config.prod.vvc" -}}
vvc:
  cloudManager:
    endpoint: {{ .Values.cloudManager.endpoint }}
    pyxis:
      product: "flink"
      cluster:
        - region: eu-central-1
          id: "vvc-eu-central-1"
          workspaceRegion: germany
        - region: us-west-1
          id: "vvc-us-west-1"
          workspaceRegion: us-west
        - region: us-east-1
          id: "vvc-us-east-1"
          workspaceRegion: us-east
{{- end }}
