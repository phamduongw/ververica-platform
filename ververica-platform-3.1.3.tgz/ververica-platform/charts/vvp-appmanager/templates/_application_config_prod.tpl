{{- define "appmanager.config.prod" -}}
{{- /* Registry pull secret for the Flink JM/TM pods, passed to the two platform-owned SYSTEM
       defaults blobs below and to nothing else — the `global*Defaults` blobs are the operator's
       surface and the platform does not write into them. Consumed on OpenShift only — see
       `common.flinkDefaultsBlob` in the common library chart. Defined here rather than beside the blobs
       so the whitespace around them, and therefore the off-OpenShift render, is untouched.

       Deliberately `global.imagePullSecretName` alone, with no chart-level fallback. The obvious
       candidate, `.Values.serviceAccount.imagePullSecret`, is the AppManager *service* pod's own
       secret, whereas the mechanism this replaces reads `rbac.imagePullSecret` from vvp-appagent —
       a value this chart cannot see. Falling back to the wrong one of those would give the Flink
       pods a different secret on OpenShift than off it, silently. When the global is unset the key
       is simply omitted, which leaves OpenShift exactly as broken as before and no more. */ -}}
{{- $flinkPullSecret := (.Values.global).imagePullSecretName -}}
vvp:
  analytics:
    enabled: false

  platform-kubernetes-namespace: {{ .Release.Namespace | quote }}
  flinkDeploymentDefaults:
    registry: {{ default .Values.flink.image.registry (.Values.global).image.registry }}
    repository: {{ .Values.flink.image.repository }}

  license:
    acceptCommunityEditionLicense: false

  persistence:
    type: jdbc
    listenerPoolSize: 32
  supportClusters:
    - kubernetes

  appmanager:
    controllers:
      ssl-enabled: false
    artifact-fetcher:
      general.connect-timeout: 30
      general.read-timeout: 3600
    persistence:
      dataDir: /vvp/data/appmanager/
      maximumNumberOfFolders: 300
      maximumNumberOfItemsPerFolder: 1000
    cluster:
      controller.health-score-scheduler.delay-ms: 60000
      controller.scheduler.workers: 100
      kubernetes.http-client.thread-pool-size: 200
      kubernetes.artifact-fetcher.image-registry: {{ default .Values.service.artifactFetcher.kubernetesArtifactFetcher.image.registry (.Values.global).image.registry | quote }}
      kubernetes.artifact-fetcher.image-repository: {{ .Values.service.artifactFetcher.kubernetesArtifactFetcher.image.repository | quote }}
      kubernetes.artifact-fetcher.image-tag: {{ .Values.service.artifactFetcher.kubernetesArtifactFetcher.image.tag | quote }}
      {{- /* FEED-978: private-CA trust for the artifact-fetcher, from values.
             When global.security.artifactFetcherCA is unset the literal defaults
             below render byte-identical to the previous chart version. */}}
      {{- $fetcherCA := ((.Values.global).security).artifactFetcherCA | default (dict) }}
      {{- if $fetcherCA.secretName }}
      kubernetes.artifact-fetcher.env-vars: {{ include "common.artifactFetcherCAEnv" (dict "root" . "withComponent" true) | fromYamlArray | toJson | quote }}
      kubernetes.artifact-fetcher.volumes: {{ include "common.artifactFetcherCAVolumes" (dict "root" . "cachePath" "/home/t4/vvp/filecache") | fromYamlArray | toJson | quote }}
      kubernetes.artifact-fetcher.volume-mounts: {{ include "common.artifactFetcherCAVolumeMounts" (dict "root" . "withCache" true) | fromYamlArray | toJson | quote }}
      {{- else }}
      kubernetes.artifact-fetcher.env-vars:  "- name: COMPONENT\n  value: artifact-fetcher"
      {{- /* hostPath is forbidden by restricted-v2 and by PodSecurity `restricted`, so on
             OpenShift the fetcher pod is refused and no artifact can be fetched. emptyDir keeps
             the mount contract; only node-level cache sharing is lost. See
             common.artifactFetcherCAVolumes for the same swap on the private-CA path. */}}
      {{- if eq (include "common.isOpenShift" .) "true" }}
      kubernetes.artifact-fetcher.volumes:  "- name: cache-dir\n  emptyDir: {}"
      {{- else }}
      kubernetes.artifact-fetcher.volumes:  "- name: cache-dir\n  hostPath:\n    path: /home/t4/vvp/filecache\n    type: DirectoryOrCreate"
      {{- end }}
      kubernetes.artifact-fetcher.volume-mounts:  "- name: cache-dir\n  mountPath: /vvp/filecache"
      {{- end }}
    local: false
    force-terminate-enabled: {{ .Values.service.forceTerminateEnabled }}
    scheduler:
      sch.group.name: {{ .Values.service.scheduler.schGroupName }}
      sch.capacity: {{ .Values.service.scheduler.schCapacity }}
      sch.interval.ms: {{ .Values.service.scheduler.schIntervalMs }}
      sch.history.clear.ttl.sec: {{ .Values.service.scheduler.schHistoryClearTtlSec }}
  flinkExceptionProperties:
    openFetch: false
    openAggregation: false
    openSearch: false
  jobDiagnosisProperties:
    openDiagnosis: false
    openHealthScore: false
  defaultFlinkVersionName: 'vvr-0.5.0-flink-1.15'
  flinkVersionMetadata:
    - versionName: 'vvr-0.5.0-flink-1.15'
      id: 'c6963387-5471-424e-a23e-0d3fccef15ac'
      flinkVersion: '1.15'
      vvrVersion: '0.5.0'
      imageTag: '1.15-vvr-0.5.0-s3-log-vvp-hadoop3.1.3'
      status: 'STABLE'
      features:
        useForSqlDeployments: true
        supportStateCompatibility: true
        supportFindUsedCatalogs: true
        supportLogPaging: true
        supportLogArchive: true
        supportDynamicLogLevel: true
        supportJvmDebug: true
        supportNativeSavepoint: true
        supportNativeK8s: true


  globalDeploymentDefaults: |
{{ include "common.flinkDefaultsBlob" (dict "blob" (include "appmanager.globalDeploymentDefaults" .) "context" .) | indent 4 }}

  flinkConfigurationStream: |-
{{ .Values.flinkConfigurationStream | indent 4 }}

  flinkConfigurationBatch: |-
{{ .Values.flinkConfigurationBatch | indent 4 }}

  systemDeploymentDefaults: |-
{{ include "common.flinkDefaultsBlob" (dict "blob" .Values.systemDeploymentDefaults "context" . "pullSecret" $flinkPullSecret) | indent 4 }}

  systemSessionClusterDefaults: |-
{{ include "common.flinkDefaultsBlob" (dict "blob" .Values.systemSessionClusterDefaults "context" . "pullSecret" $flinkPullSecret) | indent 4 }}
{{- if .Values.globalSessionClusterDefaults }}

  globalSessionClusterDefaults: |-
{{ include "common.flinkDefaultsBlob" (dict "blob" .Values.globalSessionClusterDefaults "context" .) | indent 4 }}
{{- end }}

  flinkLoggingProfiles:
  - name: default
    template: |
      <?xml version="1.0" encoding="UTF-8" standalone="no"?>
      <Configuration xmlns="http://logging.apache.org/log4j/2.0/config" strict="true" monitorInterval="30">
          <Appenders>
              <Appender name="StdOut" type="Console">
                  <Layout pattern="%d{yyyy-MM-dd HH:mm:ss,SSS} [%-tn] %-5p %-60c %x - %m%n" type="PatternLayout" charset="UTF-8"/>
              </Appender>
              <Appender name="RollingFile" type="RollingFile" fileName="${sys:$}{sys:log.file}" filePattern="${sys:$}{sys:log.file}.%i">
                  <Layout pattern="%d{yyyy-MM-dd HH:mm:ss,SSS} [%-tn] %-5p %-60c %x - %m%n" type="PatternLayout" charset="UTF-8"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="5 MB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="1"/>
              </Appender>
              <Appender name="StdOutErrConsoleAppender" type="Console">
                  <Layout pattern="%m" type="PatternLayout" charset="UTF-8"/>
              </Appender>
              <Appender name="StdOutFileAppender" type="RollingFile" fileName="${sys:$}{sys:stdout.file}" filePattern="${sys:$}{sys:stdout.file}.%i">
                  <Layout pattern="%m" type="PatternLayout" charset="UTF-8"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="5 MB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="2"/>
              </Appender>
              <Appender name="StdErrFileAppender" type="RollingFile" fileName="${sys:$}{sys:stderr.file}" filePattern="${sys:$}{sys:stderr.file}.%i">
                  <Layout pattern="%m" type="PatternLayout" charset="UTF-8"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="5 MB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="2"/>
              </Appender>
          </Appenders>
          <Loggers>
              <Logger level="INFO" name="org.apache.hadoop"/>
              <Logger level="INFO" name="org.apache.kafka"/>
              <Logger level="INFO" name="org.apache.zookeeper"/>
              <Logger level="INFO" name="akka"/>
              <Logger level="ERROR" name="org.jboss.netty.channel.DefaultChannelPipeline"/>
              <Logger level="OFF" name="org.apache.flink.runtime.rest.handler.job.JobDetailsHandler"/>
              <Logger level="INFO" name="StdOutErrRedirector.StdOut" additivity="false">
                  <AppenderRef ref="StdOutFileAppender"/>
                  <AppenderRef ref="StdOutErrConsoleAppender"/>
              </Logger>
              <Logger level="INFO" name="StdOutErrRedirector.StdErr" additivity="false">
                  <AppenderRef ref="StdErrFileAppender"/>
                  <AppenderRef ref="StdOutErrConsoleAppender"/>
              </Logger>
              {%- for name, level in userConfiguredLoggers -%}
              <Logger level="{{- printf "{{ %s }}" "level" }}" name="{{- printf "{{ %s }}" "name" }}"/>
              {%- endfor -%}
              <Root level="{{- printf "{{ %s }}" "rootLoggerLogLevel" }}">
                  <AppenderRef ref="StdOut"/>
                  <AppenderRef ref="RollingFile"/>
              </Root>
          </Loggers>
      </Configuration>
{{- end }}
