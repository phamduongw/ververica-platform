
{{/* app name */}}
{{- define "appname" -}}
{{- $appname := "vvp" }}
{{- printf "%s" $appname -}}
{{- end }}

{{/* appmanager name */}}
{{- define "appmanager.name" -}}
{{- $name := "appmanager" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/* service account name */}}
{{- define "appmanager.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "appmanager.name" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
appmanager.globalDeploymentDefaults - serialise the structured `globalDeploymentDefaults` tree
into the YAML string AppManager binds to that property. Serialising here rather than in values
is what lets `--set` reach a single field: Helm merges the tree per leaf, then this stringifies.

Empty leaves are omitted, never emitted as null: AppManager applies the result as an RFC-7386
merge patch, where an explicit null deletes the key from the layer below.
*/}}
{{- define "appmanager.globalDeploymentDefaults" -}}
{{- $v := .Values.globalDeploymentDefaults | default dict -}}
{{- $resources := dict -}}
{{- range $role := list "jobmanager" "taskmanager" -}}
{{- $r := dict -}}
{{- $cpu := dig $role "cpu" "" $v -}}
{{- $memory := dig $role "memory" "" $v -}}
{{- if $cpu }}{{- $_ := set $r "cpu" $cpu -}}{{- end -}}
{{- if $memory }}{{- $_ := set $r "memory" $memory -}}{{- end -}}
{{- if $r }}{{- $_ := set $resources $role $r -}}{{- end -}}
{{- end -}}
{{- $flinkConfiguration := deepCopy ($v.flinkConfiguration | default dict) -}}
{{- if $v.numberOfTaskSlots -}}
{{- $_ := set $flinkConfiguration "taskmanager.numberOfTaskSlots" (printf "%v" $v.numberOfTaskSlots) -}}
{{- end -}}
{{- $templateSpec := dict -}}
{{- if $resources }}{{- $_ := set $templateSpec "resources" $resources -}}{{- end -}}
{{- if $flinkConfiguration }}{{- $_ := set $templateSpec "flinkConfiguration" $flinkConfiguration -}}{{- end -}}
{{- $shorthand := dict -}}
{{- if $templateSpec }}{{- $_ := set $shorthand "template" (dict "spec" $templateSpec) -}}{{- end -}}
{{- if $v.upgradeStrategy }}{{- $_ := set $shorthand "upgradeStrategy" (dict "kind" $v.upgradeStrategy) -}}{{- end -}}
{{- $spec := mergeOverwrite (deepCopy ($v.spec | default dict)) $shorthand -}}
{{- $out := dict -}}
{{- if $spec }}{{- $_ := set $out "spec" $spec -}}{{- end -}}
{{- if $v.batchSpec }}{{- $_ := set $out "batchSpec" (deepCopy $v.batchSpec) -}}{{- end -}}
{{- if $out }}{{- toYaml $out -}}{{- end -}}
{{- end }}

