{{/* app name */}}
{{- define "appname" -}}
{{- $appname := "vvp" }}
{{- printf "%s" $appname -}}
{{- end }}

{{/* ui name */}}
{{- define "consoleui.name" -}}
{{- $name := "console-ui" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end }}
