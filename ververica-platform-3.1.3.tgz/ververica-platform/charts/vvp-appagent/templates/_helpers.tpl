
{{/* app name */}}
{{- define "appname" -}}
{{- $appname := "vvp" }}
{{- printf "%s" $appname -}}
{{- end }}

{{/* agent name */}}
{{- define "agent.name" -}}
{{- $name := "agent" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* sql name */}}
{{- define "sql.name" -}}
{{- $name := "sql" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* jar name */}}
{{- define "jar.name" -}}
{{- $name := "jar" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* nginx name */}}
{{- define "nginx.name" -}}
{{- $name := "nginx" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* rbac name */}}
{{- define "rbac.name" -}}
{{- $application := "flink" -}}
{{- $type := "sa" -}}
{{- printf "%s-%s-%s" $application (include "appname" .) $type | trunc 63 | trimSuffix "-" -}}
{{- end -}}
