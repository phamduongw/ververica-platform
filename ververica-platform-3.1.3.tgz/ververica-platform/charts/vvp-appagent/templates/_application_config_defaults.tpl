{{- define "application.config.defaults" -}}
{{- /* The vvp-sql and vvp-jar services create Flink JobManager and TaskManager pods of their own
       — SQL preview session clusters, for one — so their system blobs need the same OpenShift
       treatment as vvp-appmanager's: the registry pull secret on the pod spec, because the JM/TM
       ServiceAccounts cannot carry it there (VCP-13131). Rendering these verbatim left those pods
       with no credential path on OpenShift while deployments created through AppManager had one.

       Same rules as the appmanager side: SYSTEM blobs only, never the operator-owned `global*`
       ones; `global.imagePullSecretName` with no chart-level fallback, so the Flink pods cannot
       end up with a different secret per platform; and consumed on OpenShift only, so the
       off-OpenShift render stays byte-identical.

       Defined here rather than beside the blobs: a `{{- ... -}}` there trims the preceding
       newline and glues `systemDeploymentDefaults:` onto the end of the previous value, which
       silently stops it being a key at all. */ -}}
{{- $flinkPullSecret := (.Values.global).imagePullSecretName -}}
vvp:
  releaseVersion: {{ .Values.vvp.releaseVersion }}
  analytics:
    enabled: false
  platform-kubernetes-namespace: {{ .Release.Namespace | quote }}
  flinkDeploymentDefaults:
    registry: {{ default .Values.flinkDeploymentDefaults.image.registry (.Values.global).image.registry }}
    repository: {{ .Values.flinkDeploymentDefaults.image.repository }}
  license:
    acceptCommunityEditionLicense: false
  {{/*
  In version 2.1.3, we should combine all old vvp database files into one.
  And in version 2.2, germany team won't support old database files. At that time, we have to use `local` persistence type.
  */}}
  persistence:
    type: jdbc
    datasource:
      hikari:
        maximum-pool-size: 1

  supportClusters:
    - kubernetes

  appmanager:
    artifact-fetcher:
      general.connect-timeout: 30
      general.read-timeout: 3600
    persistence:
      dataDir: /vvp/data/appmanager/
    cluster:
      controller.scheduler.workers: 32
      kubernetes.http-client.thread-pool-size: 32
      kubernetes.artifact-fetcher.image-registry: {{ default .Values.cluster.kubernetesArtifactFetcher.image.registry (.Values.global).image.registry | quote }}
      kubernetes.artifact-fetcher.image-repository: {{ .Values.cluster.kubernetesArtifactFetcher.image.repository | quote }}
      kubernetes.artifact-fetcher.image-tag: {{ .Values.cluster.kubernetesArtifactFetcher.image.tag | quote }}
      {{- /* FEED-978: private-CA trust for the artifact-fetcher, from values.
             Unset knob renders the literal defaults byte-identical to before
             (note: no env-vars key here in the stock chart, so none is added). */}}
      {{- $fetcherCA := ((.Values.global).security).artifactFetcherCA | default (dict) }}
      {{- if $fetcherCA.secretName }}
      kubernetes.artifact-fetcher.env-vars: {{ include "common.artifactFetcherCAEnv" (dict "root" . "withComponent" false) | fromYamlArray | toJson | quote }}
      kubernetes.artifact-fetcher.volumes: {{ include "common.artifactFetcherCAVolumes" (dict "root" . "cachePath" "/tmp/filecache") | fromYamlArray | toJson | quote }}
      kubernetes.artifact-fetcher.volume-mounts: {{ include "common.artifactFetcherCAVolumeMounts" (dict "root" . "withCache" true) | fromYamlArray | toJson | quote }}
      {{- else }}
      {{- /* hostPath is forbidden by restricted-v2 and by PodSecurity `restricted`, so on
             OpenShift the fetcher pod is refused and no artifact can be fetched. emptyDir keeps
             the mount contract; only node-level cache sharing is lost. See
             common.artifactFetcherCAVolumes for the same swap on the private-CA path. */}}
      {{- if eq (include "common.isOpenShift" .) "true" }}
      kubernetes.artifact-fetcher.volumes:  "- name: cache-dir\n  emptyDir: {}"
      {{- else }}
      kubernetes.artifact-fetcher.volumes:  "- name: cache-dir\n  hostPath:\n    path: /tmp/filecache\n    type: DirectoryOrCreate"
      {{- end }}
      kubernetes.artifact-fetcher.volume-mounts:  "- name: cache-dir\n  mountPath: /vvp/filecache"
      {{- end }}
    local: false

  sql-service:
    flinkServerLifetime: 48h
    pool:
      coreSize: {{ or .Values.sqlService.poolConfig.coreSize 2}}
      maxSize: {{or .Values.sqlService.poolConfig.maxSize 50}}
      capacity: {{or .Values.sqlService.poolConfig.capacity 300}}
    sqlserver:
      sqlServerLocalDir: /vvp/data/sql/sqlserver
      javaHome: /opt/java/openjdk
      jvmArgs: '-XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m -XX:MinMetaspaceFreeRatio=0 -XX:MaxMetaspaceFreeRatio=100 -XX:+ExitOnOutOfMemoryError -Dalicloud.sts.credential.provider=sts.file -Dsts.provider.file.credential.root.path=/vvp/sts-secrets -Dsts.provider.credential.expire.seconds=900 -Dlog4j2.formatMsgNoLookups=true'
      maxInboundMessageSize: 209715200
      maxInboundMetadataSize: 209715200
      numManagerWorker: 1
    catalog:
      defaultCatalogName: system
      defaultDatabaseName: default
      catalogCacheMaxSize: 5
      catalogCacheEvictionIntervalInMins: 60
      externalCatalogTimeoutInSecs: 30
      confLocalDir: /vvp/data/sql/catalogs
    udf:
      udfJarLocalDir: /vvp/data/sql
    jar:
      temporaryJarLocalDir: /vvp/data/sql
    temporaryFile:
      temporaryFileLocalDir: /vvp/data/sql
    flinkVersionConfigProperties:
      configMapNamePrefix: flink-version-configuration-v2-
    connector:
      catalogBaseDir: /vvp/data/sql/catalogs
      jarLocalDir: /vvp/data/sql/connectors

  jar-service:
    enabled: false
    pool:
      coreSize: 64
      maxSize: 64
      capacity: 1024
    jarserver:
      jarServerLocalDir: /vvp/data/jar/jarserver
    jar:
      temporaryJarLocalDir: /vvp/data/jar

  autopilot:
    enabled: true
    agentFactory: RTC
    endpoint: "http://{{ template "appname" . }}-sql:7080"

  artifact-transmitter:
    image-registry: {{ default .Values.cluster.kubernetesArtifactFetcher.image.registry (.Values.global).image.registry | quote }}
    image-repository: {{ .Values.cluster.kubernetesArtifactFetcher.image.repository | quote }}
    image-tag: {{ .Values.cluster.kubernetesArtifactFetcher.image.tag | quote }}
  globalDeploymentDefaults: |
{{ .Values.globalDeploymentDefaults | indent 4 }}

  flinkConfigurationStream: |-
{{ .Values.flinkConfigurationStream | indent 4 }}

  flinkConfigurationBatch: |-
{{ .Values.flinkConfigurationBatch | indent 4 }}

  systemDeploymentDefaults: |-
{{ include "common.flinkDefaultsBlob" (dict "blob" .Values.systemDeploymentDefaults "context" . "pullSecret" $flinkPullSecret) | indent 4 }}
  systemSessionClusterDefaults: |-
{{ include "common.flinkDefaultsBlob" (dict "blob" .Values.systemSessionClusterDefaults "context" . "pullSecret" $flinkPullSecret) | indent 4 }}
{{- if .Values.globalSessionClusterDefaults }}
  globalSessionClusterDefaults: |-
{{ .Values.globalSessionClusterDefaults | indent 4 }}
{{- end }}


  flinkLoggingProfiles:
  - name: default
    template: |
      <?xml version="1.0" encoding="UTF-8" standalone="no"?>
      <Configuration xmlns="http://logging.apache.org/log4j/2.0/config" strict="true" monitorInterval="30">
          <Appenders>
              <Appender name="StdOut" type="Console">
                  <Layout pattern="%d{yyyy-MM-dd HH:mm:ss,SSS} [%-tn] %-5p %-60c %x - %m%n" type="PatternLayout" charset="UTF-8"/>
              </Appender>
              <Appender name="RollingFile" type="RollingFile" fileName="${sys:$}{sys:log.file}" filePattern="${sys:$}{sys:log.file}.%i">
                  <Layout pattern="%d{yyyy-MM-dd HH:mm:ss,SSS} [%-tn] %-5p %-60c %x - %m%n" type="PatternLayout" charset="UTF-8"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="5 MB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="1"/>
              </Appender>
              <Appender name="StdOutErrConsoleAppender" type="Console">
                  <Layout pattern="%m" type="PatternLayout" charset="UTF-8"/>
              </Appender>
              <Appender name="StdOutFileAppender" type="RollingFile" fileName="${sys:$}{sys:stdout.file}" filePattern="${sys:$}{sys:stdout.file}.%i">
                  <Layout pattern="%m" type="PatternLayout" charset="UTF-8"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="5 MB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="2"/>
              </Appender>
              <Appender name="StdErrFileAppender" type="RollingFile" fileName="${sys:$}{sys:stderr.file}" filePattern="${sys:$}{sys:stderr.file}.%i">
                  <Layout pattern="%m" type="PatternLayout" charset="UTF-8"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="5 MB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="2"/>
              </Appender>
          </Appenders>
          <Loggers>
              <Logger level="INFO" name="org.apache.hadoop"/>
              <Logger level="INFO" name="org.apache.kafka"/>
              <Logger level="INFO" name="org.apache.zookeeper"/>
              <Logger level="INFO" name="akka"/>
              <Logger level="ERROR" name="org.jboss.netty.channel.DefaultChannelPipeline"/>
              <Logger level="OFF" name="org.apache.flink.runtime.rest.handler.job.JobDetailsHandler"/>
              <Logger level="INFO" name="StdOutErrRedirector.StdOut" additivity="false">
                  <AppenderRef ref="StdOutFileAppender"/>
                  <AppenderRef ref="StdOutErrConsoleAppender"/>
              </Logger>
              <Logger level="INFO" name="StdOutErrRedirector.StdErr" additivity="false">
                  <AppenderRef ref="StdErrFileAppender"/>
                  <AppenderRef ref="StdOutErrConsoleAppender"/>
              </Logger>
              {%- for name, level in userConfiguredLoggers -%}
              <Logger level="{{- printf "{{ %s }}" "level" }}" name="{{- printf "{{ %s }}" "name" }}"/>
              {%- endfor -%}
              <Root level="{{- printf "{{ %s }}" "rootLoggerLogLevel" }}">
                  <AppenderRef ref="StdOut"/>
                  <AppenderRef ref="RollingFile"/>
              </Root>
          </Loggers>
      </Configuration>

{{- end }}
