{{- define "gateway.config.defaults" -}}
vvp:
  sqlService:
    enabled: false
  defaultFlinkVersionName: 'fake'
  resultFetcher:
    registry: eu.gcr.io/vvp-devel-240810
    repository: vvp-result-fetcher-service
    tag: latest
  releaseVersion: 2.2.0
  analytics:
    enabled: false
  platformKubernetesNamespace: default
  flinkDeploymentDefaults:
    registry:
    repository:
  license:
    acceptCommunityEditionLicense: false

  persistence:
    type: jdbc

  supportClusters:
    - kubernetes

  autopilot:
    enabled: true
    agentFactory: RTC

  ui:
    linkTemplates:
      flinkUi: "/flink-ui/v1/<%= workspace %>/<%= namespace %>/jobs/<%= jobId %>/"
      sessionClusterFlinkUi: /flink-ui/v1/<%= workspace %>/<%= namespace %>/sessionclusters/<%= sessionClusterName %>/
  gateway:
    domainName: domain.local
    services:
      ui-endpoint: http://127.0.0.1:4200
      sql-service-enabled: true

    httpClient:
      connectTimeout: 10000
      connectionRequestTimeout: 60000
      socketTimeout: 300000
      maxConnPerRoute: 50
      maxConnTotal: 500

    dashboard:
      apiEndpoint: http://#(region).a.b.com:9090/api/v1/arms/#(uid)/#(workspace)/#(region)/api/v1/

    storage:
      type: file
      file:
        directory: /vvp/data/vvp-gateway/

    aliCloud:
      defaultRegionId: region
      accessId: accessId
      accessKey: accessKey
      endpoints:
        - {"regionId": region,"product": test,"domain": domain.com}
  auth:
    ramAuth:
      ramAuthEnabled: false

  control:
    namespaceDisplayEnabled: false
    tokenDisplayEnabled: false
    deploymentTargetAllowedAction: NONE
    allowedMemberScopes:
      - user
    multiClusterEnabled: true
    deploymentPaginationEnabled: false
    adminDisplayEnabled: false
    roleBindingAloneEnabled: true
    bucEnabled: false
    defaultCluster: default

  globalDeploymentDefaults: |
{{ .Values.globalDeploymentDefaults | indent 4 }}

  flinkLoggingProfiles:
  - name: default
    template: |
      <?xml version="1.0" encoding="UTF-8" standalone="no"?>
      <Configuration xmlns="http://logging.apache.org/log4j/2.0/config" strict="true">
          <Appenders>
              <Appender name="StdOut" type="Console">
                  <Layout pattern="%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p %-60c %x - %m%n" type="PatternLayout"/>
              </Appender>
              <Appender name="RollingFile" type="RollingFile" fileName="${sys:$}{sys:log.file}" filePattern="${sys:$}{sys:log.file}.%i">
                  <Layout pattern="%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p %-60c %x - %m%n" type="PatternLayout"/>
                  <Policies>
                      <SizeBasedTriggeringPolicy size="1 GB"/>
                  </Policies>
                  <DefaultRolloverStrategy max="2"/>
              </Appender>
          </Appenders>
          <Loggers>
              <Logger level="INFO" name="org.apache.hadoop"/>
              <Logger level="INFO" name="org.apache.kafka"/>
              <Logger level="INFO" name="org.apache.zookeeper"/>
              <Logger level="INFO" name="akka"/>
              <Logger level="ERROR" name="org.jboss.netty.channel.DefaultChannelPipeline"/>
              <Logger level="OFF" name="org.apache.flink.runtime.rest.handler.job.JobDetailsHandler"/>
              {%- for name, level in userConfiguredLoggers -%}
              <Logger level="{{- printf "{{ %s }}" "level" }}" name="{{- printf "{{ %s }}" "name" }}"/>
              {%- endfor -%}
              <Root level="{{- printf "{{ %s }}" "rootLoggerLogLevel" }}">
                  <AppenderRef ref="StdOut"/>
                  <AppenderRef ref="RollingFile"/>
              </Root>
          </Loggers>
      </Configuration>
{{- end }}
