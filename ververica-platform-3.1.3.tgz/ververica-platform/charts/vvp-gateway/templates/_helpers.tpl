
{{/* app name */}}
{{- define "appname" -}}
{{- $appname := "vvp" }}
{{- printf "%s" $appname -}}
{{- end }}

{{/* gateway name */}}
{{- define "gateway.name" -}}
{{- $name := "gateway" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/* service account name */}}
{{- define "gateway.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "gateway.name" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
