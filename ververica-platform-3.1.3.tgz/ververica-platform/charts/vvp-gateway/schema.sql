-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for Linux (x86_64)
--
-- Host: console-db-o902.cxurju3gathf.eu-central-1.rds.amazonaws.com    Database: vvp-gateway
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gateway_admin`
--

DROP TABLE IF EXISTS `gateway_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_admin` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `member` varchar(64) NOT NULL COMMENT 'æˆå‘˜åç§°',
  `role` varchar(64) NOT NULL COMMENT 'adminè§’è‰²',
  `gmt_create` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_member` (`member`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='ç®¡ç†å‘˜è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_alarm_rule`
--

DROP TABLE IF EXISTS `gateway_alarm_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_alarm_rule` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `namespace` varchar(128) NOT NULL COMMENT 'namespace',
  `name` varchar(128) NOT NULL COMMENT 'æŠ¥è­¦è§„åˆ™åç§°',
  `content` varchar(8192) NOT NULL COMMENT 'æŠ¥è­¦è§„åˆ™å†…å®¹',
  `gmt_create` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `cluster` varchar(64) DEFAULT NULL COMMENT 'é›†ç¾¤åç§°',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`namespace`,`name`,`cluster`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='alarm_ruleè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_alarm_rule_record`
--

DROP TABLE IF EXISTS `gateway_alarm_rule_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_alarm_rule_record` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL COMMENT 'ä¿®æ”¹æ—¶é—´',
  `alarm_rule_id` varchar(128) NOT NULL COMMENT 'å‘Šè­¦è§„åˆ™å”¯ä¸€æ ‡è¯†',
  `deployment_id` varchar(128) NOT NULL COMMENT 'å‘Šè­¦è§„åˆ™å…³è”çš„deploymentId',
  `workspace` varchar(256) NOT NULL DEFAULT 'default' COMMENT 'å‘Šè­¦è§„åˆ™æ‰€åœ¨workspace',
  `namespace` varchar(512) NOT NULL COMMENT 'å‘Šè­¦è§„åˆ™æ‰€åœ¨namespace',
  `name` varchar(256) NOT NULL COMMENT 'å‘Šè­¦è§„åˆ™åç§°',
  `description` varchar(256) DEFAULT NULL COMMENT 'å‘Šè­¦è§„åˆ™æè¿°ä¿¡æ¯',
  `event_type` varchar(256) NOT NULL COMMENT 'äº‹ä»¶å‘Šè­¦è§„åˆ™ç±»åž‹',
  `status` tinyint NOT NULL COMMENT 'å‘Šè­¦è§„åˆ™çŠ¶æ€\n-2 stopped, 1 running',
  `type` varchar(256) NOT NULL COMMENT 'å‘Šè­¦è§„åˆ™ç±»åž‹',
  `notify_rule` mediumtext COMMENT 'é€šçŸ¥ç­–ç•¥',
  `notify_objects` mediumtext COMMENT 'é€šçŸ¥å¯¹è±¡',
  `creator` varchar(128) DEFAULT NULL COMMENT 'å‘Šè­¦è§„åˆ™åˆ›å»ºäºº',
  `modifier` varchar(128) DEFAULT NULL COMMENT 'å‘Šè­¦è§„åˆ™æœ€æ–°ä¿®æ”¹äºº',
  `notification_policy_id` varchar(128) NOT NULL COMMENT 'é€šçŸ¥ç­–ç•¥ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_alarm_rule_id` (`alarm_rule_id`),
  UNIQUE KEY `uk_unique_index` (`workspace`(128),`namespace`(128),`deployment_id`,`name`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='ç”¨æˆ·äº‹ä»¶å‘Šè­¦è§„åˆ™';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_api_token`
--

DROP TABLE IF EXISTS `gateway_api_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_api_token` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `type` varchar(64) NOT NULL COMMENT 'apiç±»å',
  `name` varchar(64) NOT NULL COMMENT 'apiåç§°',
  `secret` varchar(64) NOT NULL COMMENT 'å®šä¹‰api token',
  `role` mediumtext NOT NULL COMMENT 'è§’è‰²',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´1',
  `create_time` mediumtext NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´2',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `cluster` varchar(64) DEFAULT NULL COMMENT 'é›†ç¾¤åç§°',
  `namespace` varchar(128) DEFAULT NULL COMMENT 'namespaceåç§°',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`cluster`,`namespace`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='gateway apiåˆ—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_cluster`
--

DROP TABLE IF EXISTS `gateway_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_cluster` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `name` varchar(64) NOT NULL COMMENT 'clusteråç§°',
  `endpoint` varchar(128) NOT NULL COMMENT 'cluster endpoint',
  `gmt_create` date NOT NULL DEFAULT '2020-05-01' COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` date NOT NULL DEFAULT '2020-05-01' COMMENT 'ä¿®æ”¹æ—¶é—´',
  `owner` varchar(64) DEFAULT NULL COMMENT 'clusterå½’å±žäºº',
  `blob_properties` text COMMENT 'blobé…ç½®é¡¹',
  `grafana` varchar(1024) DEFAULT NULL COMMENT 'grafanaåœ°å€',
  `extras` text COMMENT 'é¢å¤–é¡¹',
  `region_id` varchar(64) DEFAULT NULL COMMENT 'regionä¿¡æ¯',
  `ask_cluster_id` varchar(128) DEFAULT NULL COMMENT 'k8s idä¿¡æ¯',
  `kube_config` text COMMENT 'kube_config base 64 ç¼–ç ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='gateway clusteråˆ—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_cluster_info`
--

DROP TABLE IF EXISTS `gateway_cluster_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_cluster_info` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `name` varchar(128) NOT NULL COMMENT 'å¥—é¤åç§°',
  `cluster_name` varchar(128) NOT NULL COMMENT 'gateway_cluster çš„ name',
  `storage_uri` varchar(255) NOT NULL COMMENT 'storageè¿žæŽ¥ä¸²ï¼ˆjsonï¼‰',
  `zookeeper_endpoint` varchar(255) NOT NULL COMMENT 'zk endpoint',
  `region` varchar(32) NOT NULL COMMENT 'region',
  `description` varchar(1024) NOT NULL DEFAULT '' COMMENT 'description',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '0, 1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  UNIQUE KEY `uk_k8s_storage_zk` (`cluster_name`,`storage_uri`,`zookeeper_endpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='é›†å›¢å†… vvp å¥—é¤è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_components_info`
--

DROP TABLE IF EXISTS `gateway_components_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_components_info` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL COMMENT 'ä¿®æ”¹æ—¶é—´',
  `region_id` varchar(128) NOT NULL COMMENT 'å¼¹å†…ä½¿ç”¨é»˜è®¤å€¼ï¼šdefaultã€‚äº‘ä¸Šä½¿ç”¨é˜¿é‡Œäº‘RegionId, ä¾‹å¦‚ï¼šcn-hangzhou | cn-shanghai',
  `name` varchar(64) NOT NULL COMMENT 'æœåŠ¡ç±»åž‹åç§°ï¼Œå¯é€‰æžšä¸¾å€¼ï¼šAPPMANAGER | AUTOPILOT',
  `env` varchar(32) NOT NULL COMMENT 'çŽ¯å¢ƒä¿¡æ¯ï¼Œæ ‡è¯†æ˜¯ç”Ÿäº§è¿˜æ˜¯é¢„å‘ï¼Œå¯é€‰æžšä¸¾å€¼ï¼šPROD | BETA',
  `endpoint` varchar(128) NOT NULL COMMENT 'æœåŠ¡å¯¹åº”çš„è®¿é—®åœ°å€',
  `extra` longtext COMMENT 'æ‰©å±•å­—æ®µ',
  `description` varchar(128) DEFAULT NULL COMMENT 'æè¿°å­—æ®µ',
  `is_default` varchar(16) DEFAULT 'false' COMMENT 'æ˜¯å¦ä¸ºé»˜è®¤èŠ‚ç‚¹. æ–°è´­é“¾è·¯ä¼šè‡ªåŠ¨å°†æµé‡å¯¼å‘è¿™ä¸ªé»˜è®¤èŠ‚ç‚¹',
  `k8s_svc_name` varchar(128) NOT NULL COMMENT 'é›†ç¾¤åœ¨k8sä¸­çš„svcName, éœ€è¦å¸¦ä¸Šns, ä»¥ä¾›è·¨nsè®¿é—®çš„åœºæ™¯',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_region_name_env` (`region_id`,`name`,`env`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='è®°å½•AppManager/AutoPilot endpoint';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_member`
--

DROP TABLE IF EXISTS `gateway_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_member` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `namespace` varchar(128) NOT NULL COMMENT 'namespace',
  `role` varchar(64) NOT NULL COMMENT 'è§’è‰²',
  `member` varchar(64) NOT NULL COMMENT 'äººå‘˜',
  `gmt_create` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `cluster` varchar(64) DEFAULT NULL COMMENT 'é›†ç¾¤åç§°',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`cluster`,`namespace`,`member`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COMMENT='memberè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_namespace`
--

DROP TABLE IF EXISTS `gateway_namespace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_namespace` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `type` varchar(64) NOT NULL COMMENT 'èµ„æºç±»å',
  `name` varchar(128) NOT NULL COMMENT 'namespaceåç§°',
  `role_bindings` mediumtext NOT NULL COMMENT 'è§’è‰²åˆ—è¡¨',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´1',
  `create_time` mediumtext NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´2',
  `lifecycle_phase` mediumtext NOT NULL COMMENT 'ç”Ÿå‘½å‘¨æœŸ',
  `cluster` varchar(64) DEFAULT NULL COMMENT 'cluster',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `preview_session_cluster_name` varchar(128) DEFAULT NULL COMMENT 'sql preview scåç§°',
  `labels` mediumtext COMMENT 'labels',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`cluster`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COMMENT='gateway namespaceåˆ—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_notice`
--

DROP TABLE IF EXISTS `gateway_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_notice` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL COMMENT 'ä¿®æ”¹æ—¶é—´',
  `notice_type` varchar(128) NOT NULL COMMENT 'æ¶ˆæ¯ç±»åž‹ï¼ŒåŒ…å«å…¬å‘Šå’Œæ›´æ–°',
  `gmt_start` datetime NOT NULL COMMENT 'ç”Ÿæ•ˆæ—¶é—´',
  `gmt_end` datetime NOT NULL COMMENT 'ç»“æŸæ—¶é—´',
  `workspaces` text COMMENT 'å±•ç¤ºèŒƒå›´ï¼Œå·¥ä½œç©ºé—´',
  `title` text NOT NULL COMMENT 'æ¶ˆæ¯æ ‡é¢˜',
  `content_zh` text COMMENT 'ä¸­æ–‡å†…å®¹',
  `content_en` text COMMENT 'è‹±æ–‡å†…å®¹',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='æ¶ˆæ¯æŽ¨é€è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_system`
--

DROP TABLE IF EXISTS `gateway_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_system` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `type` varchar(64) NOT NULL COMMENT 'systemSettingç±»å',
  `name` varchar(64) NOT NULL COMMENT 'systemSettingåç§°',
  `value` mediumtext NOT NULL COMMENT 'systemSettingå†…å®¹',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='gateway systemSettingåˆ—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_user`
--

DROP TABLE IF EXISTS `gateway_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `emp_id` varchar(64) NOT NULL COMMENT 'å·¥å·',
  `name` varchar(64) NOT NULL COMMENT 'å‘˜å·¥å§“å',
  `nick` varchar(64) NOT NULL COMMENT 'å‘˜å·¥èŠ±å',
  `account_name` varchar(64) NOT NULL COMMENT 'åŸŸå',
  `email` varchar(64) DEFAULT NULL COMMENT 'é‚®ç®±',
  `gmt_create` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_emp_id` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='ç”¨æˆ·ä¿¡æ¯è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_vc_upgrade_info`
--

DROP TABLE IF EXISTS `gateway_vc_upgrade_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_vc_upgrade_info` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `workspace_name` varchar(64) NOT NULL COMMENT 'ç”¨æˆ·é›†ç¾¤çš„vcId, å¼¹å†…ä¸ºé›†ç¾¤åç§°(e.g. sh_02)',
  `status` varchar(64) NOT NULL COMMENT 'å‡çº§çŠ¶æ€: \n\nSTOPPED: è¡¨ç¤ºå½“å‰çŠ¶æ€ä¸º''åœæœ''\nFINISH: è¡¨ç¤ºå½“å‰çŠ¶æ€ä¸º''å‡çº§å®Œæˆ''',
  PRIMARY KEY (`id`),
  KEY `idx_workspace_name` (`workspace_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COMMENT='å‡çº§è¡¨, è®°å½•äº†æ¯ä¸ªvcçš„å‡çº§çŠ¶æ€';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gateway_ws_route`
--

DROP TABLE IF EXISTS `gateway_ws_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_ws_route` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `gmt_create` datetime NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime NOT NULL COMMENT 'ä¿®æ”¹æ—¶é—´',
  `region_id` varchar(128) NOT NULL COMMENT 'Region IDå½•å…¥æ—¶å¡«å…¥ï¼Œä¸å¯æ”¹å˜',
  `workspace` varchar(128) NOT NULL COMMENT 'Workspaceåå­—',
  `appmanager_id` bigint NOT NULL COMMENT 'å…³è”componentsä¸­AppManagerå¯¹åº”æ¡ç›®çš„ID',
  `autopilot_id` bigint NOT NULL COMMENT 'å…³è”componentsä¸­AutoPilotå¯¹åº”æ¡ç›®ID',
  `meta_id` bigint NOT NULL COMMENT 'metaç»„ä»¶id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_workspace` (`workspace`),
  KEY `idx_appmanager_id` (`appmanager_id`),
  KEY `idx_autopilot_id` (`autopilot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Gatewayä¸­workspaceåˆ°AppManager/AutoPilotçš„è·¯ç”±è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vvp_artifact`
--

DROP TABLE IF EXISTS `vvp_artifact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vvp_artifact` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `name` varchar(128) NOT NULL COMMENT 'èµ„æºåç§°',
  `filename` varchar(128) NOT NULL COMMENT 'æ–‡ä»¶åç§°',
  `cluster_name` varchar(128) DEFAULT 'default ' COMMENT 'é›†ç¾¤åç§°',
  `namespace` varchar(128) NOT NULL DEFAULT '' COMMENT 'namespace',
  `jar_url` mediumtext COMMENT 'JARåŒ…URLåœ°å€',
  `gmt_create` datetime DEFAULT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `gmt_modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `uploader` varchar(128) DEFAULT NULL COMMENT 'èµ„æºçš„ä¸Šä¼ äºº',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  UNIQUE KEY `uk_name_cluster_ns` (`name`,`cluster_name`,`namespace`)
) ENGINE=InnoDB AUTO_INCREMENT=674 DEFAULT CHARSET=utf8mb3 COMMENT='èµ„æºä¿¡æ¯è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-05 20:36:47
