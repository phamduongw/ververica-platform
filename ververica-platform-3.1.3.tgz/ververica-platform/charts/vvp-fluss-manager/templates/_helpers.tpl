{{/* app name */}}
{{- define "appname" -}}
{{- $appname := "vvp" }}
{{- printf "%s" $appname -}}
{{- end }}

{{/*
No `define "component"` here on purpose. Helm template names are GLOBAL across the whole
chart tree, not scoped per subchart — two charts defining the same name collide and the
load order decides which wins. charts/vvp-advisor already defines a generic "component",
so defining one here silently labelled this chart's pods `component: advisor`, which put
them behind the advisor Service. Every other chart (vvp-meta, vvp-gateway, ...) inlines
the literal instead; this one does too.
*/}}

{{/* fluss-manager name */}}
{{- define "fluss-manager.name" -}}
{{- $name := "fluss-manager" -}}
{{- printf "%s-%s" (include "appname" .) $name | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/* service account name */}}
{{- define "fluss-manager.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "fluss-manager.name" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
